import pyautogui as py

py.hotkey("win","left")
py.press("enter")

py.write(" EH  UM  ATAQUE      !!!!!!!!!!!")