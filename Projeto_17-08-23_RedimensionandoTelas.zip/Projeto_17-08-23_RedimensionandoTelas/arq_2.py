import pyautogui
import subprocess
import time

# Abrir a primeira instância do Notepad
subprocess.Popen(["notepad.exe"])
time.sleep(1)  # Aguardar para a janela do Notepad abrir

# Abrir a segunda instância do Notepad
subprocess.Popen(["notepad.exe"])
time.sleep(1)  # Aguardar para a janela do Notepad abrir

# Obtém a largura e altura da tela
screen_width, screen_height = pyautogui.size()

# Define as posições e tamanhos para as janelas
top_left_x = 0
top_left_y = 0
window_width = screen_width // 2
window_height = screen_height // 2

bottom_left_x = 0
bottom_left_y = window_height

pyautogui.write("								!!!!!!!!!!!      ISSO    NAO")
# Move e redimensiona as janelas do Notepad
pyautogui.getWindowsWithTitle("Sem título - Bloco de Notas")[0].moveTo(top_left_x, top_left_y)
pyautogui.getWindowsWithTitle("Sem título - Bloco de Notas")[0].resizeTo(window_width, window_height)


pyautogui.getWindowsWithTitle("Sem título - Bloco de Notas")[1].moveTo(bottom_left_x, bottom_left_y)
pyautogui.getWindowsWithTitle("Sem título - Bloco de Notas")[1].resizeTo(window_width, window_height)


# Aguarda um pouco antes de fechar o programa
pyautogui.sleep(1)