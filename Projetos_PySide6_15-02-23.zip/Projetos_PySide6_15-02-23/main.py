from PySide6.QtWidgets import *





class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout() 
        self.setStyleSheet('background-color: #363636')
        



        # # PRINT
        # self.nome = QLabel(self)
        # self.nome.setText('Code Key')
        # lay = QVBoxLayout()
        # lay.addWidget(self.nome)
        # self.setLayout(lay)
        # self.show()
        ##############################################################




        # # BUTTON
        # but = QPushButton("Pressione Aqui !",self)
        # but.setGeometry(10, 10, 200, 50)
        # but.clicked.connect(self.but_1)
        ##############################################################




        # # TAMANHO DA TELA
        self.setFixedSize(1280,720)
        ##############################################################




        # # INPUT
        nome_field = QLineEdit(self)
        nome_field.move(600, 360)
        ##############################################################




        # # PEGAR VALOR DO INPUT
        nome_field.toPlainText()
        ##############################################################




        # # FRAME
        qd = QFrame()
        qd.setGeometry(100, 100, 100, 100)
        qd.setStyleSheet("background-color: red;")
        ##############################################################




        # # AUMENTAR O TAMANHO DA ÁREA DO INPUT 
        self.titulo.setFixedWidth(300)
        self.titulo.setFixedHeight(300)
        ##############################################################




        # # LAYOUT
        ##############################################################


    def but_1(self):
        print('1')


app = QApplication([])
tela = MainWindow()
tela.show()
app.exec_()













